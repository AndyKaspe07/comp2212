# Sift - How to Use

Run using 'stack exec sift <path_to_cql_file>'

Make sure CSVs are in the directory you are running stack exec from